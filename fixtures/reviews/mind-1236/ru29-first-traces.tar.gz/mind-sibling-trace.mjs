import { registerHooks } from 'node:module';
import { readdirSync, readFileSync } from 'node:fs';
import { join } from 'node:path';

globalThis.mindSiblingSnapshot = () => {
  const dir = process.env.ISKRON_BRIDGE_AUTH_DIR;
  try {
    return readdirSync(dir).filter(n => /^opencode-(stopped|ended|lost)/.test(n))
      .map(n => ({ name: n, body: readFileSync(join(dir, n), 'utf8') }));
  } catch { return []; }
};

// Test-boundary observation only; neither bridge nor plugin code is transformed.
registerHooks({
  load(url, context, nextLoad) {
    const result = nextLoad(url, context);
    if (!url.endsWith('/js/tests/opencode-kit.mjs') &&
        !url.endsWith('/js/tests/opencode-siblings.test.mjs')) return result;
    let source = String(result.source);
    const replace = (needle, replacement) => {
      if (!source.includes(needle)) throw new Error(`missing trace seam: ${needle}`);
      source = source.replace(needle, replacement);
    };
    if (url.endsWith('/opencode-kit.mjs')) {
      replace('  const interrupts = [];', `
        const interrupts = [];
        const traceInstance = (globalThis.mindSiblingInstance = (globalThis.mindSiblingInstance || 0) + 1);
        console.log('SIBLING_TRACE', JSON.stringify({ at: Date.now(), event: 'context-created', traceInstance, sessions }));`);
      replace('  const def = await loadPlugin(env);', `
        console.log('SIBLING_TRACE', JSON.stringify({ at: Date.now(), event: 'after-marker-cleanup', markers: globalThis.mindSiblingSnapshot() }));
        const def = await loadPlugin(env);`);
      replace('        interrupts.push(o);', `
        console.log('SIBLING_TRACE', JSON.stringify({ at: Date.now(), event: 'interrupt-call', traceInstance, args: o, stack: new Error().stack, markers: globalThis.mindSiblingSnapshot() }));
        interrupts.push(o);
        if (process.env.MIND_INTERRUPT_DELAY)
          await new Promise(r => setTimeout(r, Number(process.env.MIND_INTERRUPT_DELAY)));`);
      replace('        return { interrupted: true };', `
        console.log('SIBLING_TRACE', JSON.stringify({ at: Date.now(), event: 'interrupt-return', args: o }));
        return { interrupted: true };`);
      replace('    await rec.cleanup?.();', `
        console.log('SIBLING_TRACE', JSON.stringify({ at: Date.now(), event: 'cleanup-start', sessions: ctxOpts.sessions, interrupts: rec.interrupts }));
        await rec.cleanup?.();
        console.log('SIBLING_TRACE', JSON.stringify({ at: Date.now(), event: 'cleanup-end', sessions: ctxOpts.sessions, interrupts: rec.interrupts, markers: globalThis.mindSiblingSnapshot() }));`);
    } else {
      if (process.env.MIND_UNIQUE_SESSIONS === '1')
        source = source.replace(/"(root|live|zombie)"/g, (_, id) => `(${JSON.stringify(id)} + '-' + how + '-' + noId)`);
      if (process.env.MIND_REUSE_PLACE === '1')
        replace('        const name = `sib-${how.length}-${noId ? 1 : 0}`;', '        const name = `sib-${how.length}-reused`;');
      replace('          const r = await rec.call("iskron_stand", { realm: "nks-dev" }, s);', `
          console.log('SIBLING_TRACE', JSON.stringify({ at: Date.now(), event: 'stand-child-start', sessionID: s }));
          const r = await rec.call("iskron_stand", { realm: "nks-dev" }, s);
          console.log('SIBLING_TRACE', JSON.stringify({ at: Date.now(), event: 'stand-child-end', sessionID: s }));`);
      replace('        await put(fake, zombie, seats);', `
        console.log('SIBLING_TRACE', JSON.stringify({ at: Date.now(), event: 'put-start', how, noId, seats, markers: globalThis.mindSiblingSnapshot() }));
        await put(fake, zombie, seats);
        console.log('SIBLING_TRACE', JSON.stringify({ at: Date.now(), event: 'put-end' }));`);
      replace('        await rec.stop();', `
        console.log('SIBLING_TRACE', JSON.stringify({ at: Date.now(), event: 'before-cleanup', interrupts: rec.interrupts, said: rec.said(), calls: fake.state.calls, sockets: [...fake.state.wsNames.values()] }));
        await rec.stop();`);
    }
    return { ...result, source };
  },
});
