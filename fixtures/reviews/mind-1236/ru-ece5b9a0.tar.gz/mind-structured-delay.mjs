import { registerHooks } from 'node:module';

registerHooks({
  load(url, context, nextLoad) {
    const result = nextLoad(url, context);
    if (!url.endsWith('/js/tests/stand.test.mjs')) return result;
    const source = String(result.source);
    const needle = [
      '    assert.deepEqual(taken.result.structuredContent, fake.state.lastStructured);',
      '    assert.deepEqual(taken.result.structuredContent, fieldsOf(taken));',
    ].find(line => source.includes(line));
    if (!needle) throw new Error('structured probe seam not found');
    return {
      ...result,
      source: source.replace(needle, `
    const before = structuredClone(fake.state.lastStructured);
    await new Promise(resolve => setTimeout(resolve, 600));
    console.log('STRUCTURED_WITNESS', JSON.stringify({
      returned: taken.result.structuredContent,
      before,
      after: fake.state.lastStructured,
      calls: fake.state.calls.filter(c => c.name === 'iskron_channel'),
    }));
    if (process.env.MIND_STRUCTURED_CORRUPT === '1')
      taken.result.structuredContent.seats[0].locale = 'corrupted-in-transit';
${needle}`),
    };
  },
});
